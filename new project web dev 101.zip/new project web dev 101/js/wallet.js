// =========================================
// WALLET.JS: 3D Wallet Drag, Money Spill, Rain Generator
// =========================================
window.addEventListener('load', () => {
    // ---- 1. RAINING MONEY GENERATOR ----
    const rainContainer = document.getElementById('rain-container');
    const symbols = ['$', '€', '៛', '¥', '£'];
    
    for (let i = 0; i < 40; i++) {
        const drop = document.createElement('div');
        drop.classList.add('money-drop');
        drop.style.left = Math.random() * 100 + 'vw';
        drop.style.fontSize = (Math.random() * 2 + 1) + 'rem';
        drop.style.animationDuration = (Math.random() * 4 + 3) + 's';
        drop.style.animationDelay = Math.random() * 5 + 's';
        drop.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        rainContainer.appendChild(drop);
    }

    // ---- 2. HERO WALLET DRAG & MONEY SPILL ----
    const walletStage = document.getElementById('wallet-stage');
    const wallet3d = document.getElementById('wallet-3d');
    const moneySpill = document.getElementById('money-spill');
    
    // Expose these to main.js so it knows when we are dragging
    window.isDragging = false;
    window.currentRotation = 0;
    
    let startX = 0;
    let isClick = true;

    const startDrag = (e) => {
        window.isDragging = true; isClick = true;
        if (e.touches && e.touches.length > 0) startX = e.touches[0].clientX;
        else startX = e.clientX || 0;
        
        wallet3d.classList.add('dragging');
        wallet3d.style.transition = 'none';
    };

    const onDrag = (e) => {
        if (!window.isDragging) return;
        if (e.cancelable) e.preventDefault(); 

        let currentX = 0;
        if (e.touches && e.touches.length > 0) currentX = e.touches[0].clientX;
        else currentX = e.clientX || 0;

        const deltaX = currentX - startX;
        if (Math.abs(deltaX) > 5) isClick = false;
        
        window.currentRotation += deltaX * 0.5;
        startX = currentX;
        
        const scrollProgress = window.scrollY / window.innerHeight;
        const scrollRotation = scrollProgress * 360; 
        wallet3d.style.transform = `rotateY(${window.currentRotation + scrollRotation}deg) rotateX(-10deg)`;
    };

    const endDrag = () => {
        if (!window.isDragging) return;
        window.isDragging = false;
        wallet3d.classList.remove('dragging');
        wallet3d.style.transition = 'transform 0.3s var(--ease)';
        
        if (isClick) {
            // Reset scroll to top instantly before opening menu
            window.targetScroll = 0;
            window.currentScroll = 0;
            window.isAnimating = false;
            window.scrollTo(0, 0);
            moneySpill.classList.toggle('active');
        }
    };

    walletStage.addEventListener('mousedown', startDrag);
    window.addEventListener('mousemove', onDrag);
    window.addEventListener('mouseup', endDrag);
    window.addEventListener('mouseleave', endDrag);

    walletStage.addEventListener('touchstart', startDrag, { passive: false });
    window.addEventListener('touchmove', onDrag, { passive: false });
    window.addEventListener('touchend', endDrag);

    // Close money spill on outside click
    document.addEventListener('click', (e) => {
        if (!moneySpill.contains(e.target) && !walletStage.contains(e.target)) {
            moneySpill.classList.remove('active');
        }
    });
});