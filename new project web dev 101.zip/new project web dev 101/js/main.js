// =========================================
// MAIN.JS: Smooth Scroll, Backgrounds, Nav, Dashboard, Roadmap
// =========================================
window.addEventListener('load', () => {
    // ---- 1. GLOBAL VARIABLES & SMOOTH SCROLL ----
    window.targetScroll = window.scrollY;
    window.currentScroll = window.scrollY;
    window.isAnimating = false;
    const ease = 0.08; 

    const moneySpill = document.getElementById('money-spill');

    const closeWalletMenu = () => {
        if (moneySpill.classList.contains('active')) {
            moneySpill.classList.remove('active');
        }
    };

    if (window.matchMedia("(min-width: 769px)").matches) {
        window.addEventListener("wheel", (e) => {
            e.preventDefault(); 
            closeWalletMenu();
            
            let delta = e.deltaY;
            if (Math.abs(delta) > 80) delta = Math.sign(delta) * 80;
            window.targetScroll += delta;
            window.targetScroll = Math.max(0, Math.min(window.targetScroll, document.body.scrollHeight - window.innerHeight));
            if (!window.isAnimating) {
                window.isAnimating = true;
                requestAnimationFrame(animateScroll);
            }
        }, { passive: false });
    }

    window.addEventListener('touchmove', (e) => {
        if (!document.getElementById('wallet-stage').contains(e.target)) {
            closeWalletMenu();
        }
    }, { passive: true });

    function animateScroll() {
        window.currentScroll += (window.targetScroll - window.currentScroll) * ease;
        if (Math.abs(window.targetScroll - window.currentScroll) < 0.5) {
            window.currentScroll = window.targetScroll;
            window.isAnimating = false;
        }
        window.scrollTo(0, window.currentScroll);
        if (window.isAnimating) requestAnimationFrame(animateScroll);
    }

    // ---- 2. CROSS-FADING BACKGROUND LAYERS ----
    const bgLayers = document.querySelectorAll('.bg-layer');
    const sections = document.querySelectorAll('[data-bg]');

    const updateBg = () => {
        const scrollY = window.scrollY + window.innerHeight / 2;
        let activeIndex = 0;
        sections.forEach((sec) => {
            if (sec.offsetTop <= scrollY && sec.offsetTop + sec.offsetHeight > scrollY) {
                activeIndex = parseInt(sec.dataset.bg);
            }
        });
        bgLayers.forEach((layer, index) => {
            if (index === activeIndex) layer.classList.add('active');
            else layer.classList.remove('active');
        });
    };

    // ---- 3. HAMBURGER TOGGLE ----
    const hamburger = document.getElementById('global-hamburger');
    const fullscreenNav = document.getElementById('fullscreen-nav');

    const handleScroll = () => {
        updateBg();
        if (window.scrollY > window.innerHeight * 0.8) hamburger.classList.add('visible');
        else {
            hamburger.classList.remove('visible');
            fullscreenNav.classList.remove('open');
            hamburger.classList.remove('open');
        }

        // Update wallet rotation based on scroll
        if (!window.isDragging) {
            const wallet3d = document.getElementById('wallet-3d');
            const bgText = document.getElementById('bg-text');
            if (wallet3d) {
                const scrollProgress = window.scrollY / window.innerHeight;
                const scrollRotation = scrollProgress * 360; 
                wallet3d.style.transform = `rotateY(${window.currentRotation + scrollRotation}deg) rotateX(${-10 + scrollProgress * 20}deg)`;
            }
            if (bgText) {
                bgText.style.transform = `translate(-50%, calc(-50% + ${window.scrollY * 0.3}px)) scale(${1 + scrollProgress * 0.5})`;
            }
        }
        updateRoadmap();
    };

    window.addEventListener('scroll', handleScroll);

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('open');
        fullscreenNav.classList.toggle('open');
    });

    // ---- 4. TERMINAL DASHBOARD ----
    const tabs = document.querySelectorAll('.currency-tabbing');
    const balanceDisplay = document.getElementById('balance-display');
    const morphNetwork = document.getElementById('morph-network');
    const morphSpeed = document.getElementById('morph-speed');
    const logLine1 = document.getElementById('log-line-1');
    const logLine2 = document.getElementById('log-line-2');

    const currencyData = {
        usd: { symbol: '$', bal: '1450.00', net: 'OnlyLuy-Direct (US-East)', spd: '0.02s' },
        khr: { symbol: '៛', bal: '5,900,000', net: 'OnlyLuy-Asia (Phnom Penh)', spd: '0.03s' },
        eur: { symbol: '€', bal: '1350.50', net: 'OnlyLuy-EU (Frankfurt)', spd: '0.01s' }
    };

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.stopPropagation();
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const curr = tab.dataset.currency;
            const data = currencyData[curr];
            balanceDisplay.textContent = `${data.symbol}${data.bal}`;
            morphNetwork.textContent = data.net;
            morphSpeed.textContent = `${data.spd} Settlement`;
            logLine1.textContent = `>> route_switch: ${curr.toUpperCase()}_PIPELINE_ACTIVE`;
            logLine2.textContent = `> conversion_rate: 1:${(Math.random()*4000 + 100).toFixed(2)}`;
        });
    });

    // ---- 5. ROADMAP SCROLL PRESENTATION ----
    const roadmapWrapper = document.getElementById('roadmap-wrapper');
    const steps = document.querySelectorAll('.roadmap-step');
    const progressFill = document.getElementById('progress-fill');
    
    roadmapWrapper.style.height = `${steps.length * 250}vh`;

    const updateRoadmap = () => {
        const rect = roadmapWrapper.getBoundingClientRect();
        const scrollableHeight = roadmapWrapper.offsetHeight - window.innerHeight;
        const scrollTop = -rect.top;

        if (scrollTop >= 0 && scrollTop <= scrollableHeight) {
            let progress = scrollTop / scrollableHeight; 
            progressFill.style.height = `${progress * 100}%`;
            
            let activeStepIndex = Math.round(progress * (steps.length - 1));
            if (activeStepIndex < 0) activeStepIndex = 0;
            if (activeStepIndex >= steps.length) activeStepIndex = steps.length - 1;

            steps.forEach((step, index) => {
                if (index === activeStepIndex) {
                    step.classList.remove('exit');
                    step.classList.add('active');
                } else if (index < activeStepIndex) {
                    step.classList.remove('active');
                    step.classList.add('exit');
                } else {
                    step.classList.remove('active');
                    step.classList.remove('exit');
                }
            });
        }
    };

    // Initial call to set correct states on load
    handleScroll(); 
});